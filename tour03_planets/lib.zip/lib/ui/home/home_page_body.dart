import 'package:flutter/material.dart';
import 'package:tour03_planets/ui/home/planet_row.dart';

class HomePageBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new PlanetRow();
  }
}